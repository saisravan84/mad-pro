package com.example.sravan.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        ListView lst = (ListView)findViewById(R.id.list);
        final ArrayList data = new ArrayList();
        data.add("Harika");
        data.add("Amar");
        data.add("Susmitha");
        data.add("Manasa");
        data.add("Harish");
        data.add("Gopi");
        data.add("Naveen");
        data.add("Ravi");
        data.add("mahesh");
        data.add("David");
        data.add("Vijay");
        data.add("Sailaja");
        data.add("Supraja");
        data.add("Neeraja");


        ArrayAdapter adapter = new ArrayAdapter(this, R.layout.activity_list_item, data);
        lst.setAdapter(adapter);

        lst.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                Intent intent = new Intent(SecondActivity.this, ThirdActivity.class);
                String name = data.get(i).toString();
                intent.putExtra("name",name);

                startActivity(intent);
            }
        });
    }
}
